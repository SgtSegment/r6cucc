Instructions:
1) Add an exclusion to your folder for the Siege version you downloaded (important!! otherwise it will delete the crack files and the game won't launch)
2) Copy all the files from the correct folder (note that Release/Vanilla Siege is included in the Y1SX-Y6S2 crack)
3) Paste them INSIDE the Siege version you downloaded
4) Click "Yes to All" when asked to overwrite files (if you don't get any notice of any file being overwritten, you pasted the files in the wrong place)
5) Depending on your version, open CPlay.ini/CODEX.ini/uplay_r2.ini with Notepad and change GAMENAME (very important!!) and USERNAME
6) Run the game by double-clicking RainbowSix.bat

Don't forget to join the Discord server: https://discord.gg/JGA9WPF4K8
Also don't forget to visit the website: https://discord.gg/JGA9WPF4K8

Thanks for:
acidicoala to make Saves working
Rat431 for his "ColdPlay" Uplay emulator
CODEX and Plaza for their Uplay Saves emulator
Goldberg for his Steam and Uplay Emulator
DLA19 for custom defaultargs.dll, updated RainbowSix.bat and repacking the Cracks